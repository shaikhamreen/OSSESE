#include<stdio.h>
  int c=0; 
       int tower(int n,char source,char dest,char aux,int step)
       {
      
       if(n==1)
       {
    
       printf("\n move %d from %c to %c,%d",n,source,dest,++c);
       }
       else
       {
       
       tower(n-1,source,aux,dest,step);
       printf("\n move %d from %c to %c,%d",n,source,aux,++c);
       tower(n-1,aux,dest,source,step);
       
     
       
       }
       }
       int main()
       {
        int n;
        int step;
        int count;
        char A,B,C;
        printf("\n enter the disk no:");
        scanf("%d",&n);
    
        //printf("\n step=%d",2^n-1);
        tower(n,'B','A','C',step);
      
                }
        
