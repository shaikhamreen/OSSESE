#include<stdio.h>
 
 int main()
      {
       int num;
       int i;
       printf("\n enter the number:");
       scanf("%d",&num);
      for(i=0;i<=num;i++)
    printf("\n fibo series=%d",fibo(i));

       }
        
    int fibo(int num)
    {
     if(num==0||num==1)
     
      return num;
      
      else
          
       return fibo(num-1)+fibo(num-2);
       
    }
     
          
 
  
